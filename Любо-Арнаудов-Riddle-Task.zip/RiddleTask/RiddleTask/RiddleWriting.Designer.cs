﻿
namespace RiddleTask
{
    partial class RiddleWriting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RiddleWriting));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.exit_button = new System.Windows.Forms.Button();
            this.back_button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxRiddles = new System.Windows.Forms.TextBox();
            this.textBoxAnswers = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button_add_new_riddles = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 451);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.Location = new System.Drawing.Point(778, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 451);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Black;
            this.pictureBox4.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(806, 21);
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Black;
            this.pictureBox3.Location = new System.Drawing.Point(-2, 430);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(806, 21);
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // exit_button
            // 
            this.exit_button.BackColor = System.Drawing.Color.White;
            this.exit_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("exit_button.BackgroundImage")));
            this.exit_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.exit_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exit_button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.exit_button.FlatAppearance.BorderSize = 5;
            this.exit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_button.Location = new System.Drawing.Point(725, 27);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(47, 44);
            this.exit_button.TabIndex = 13;
            this.exit_button.UseVisualStyleBackColor = false;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // back_button
            // 
            this.back_button.BackColor = System.Drawing.Color.White;
            this.back_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("back_button.BackgroundImage")));
            this.back_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.back_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back_button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.back_button.FlatAppearance.BorderSize = 5;
            this.back_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back_button.Location = new System.Drawing.Point(27, 380);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(47, 44);
            this.back_button.TabIndex = 14;
            this.back_button.UseVisualStyleBackColor = false;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Cursor = System.Windows.Forms.Cursors.Help;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(138, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(516, 43);
            this.label2.TabIndex = 15;
            this.label2.Text = "Riddles:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Cursor = System.Windows.Forms.Cursors.Help;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(138, 334);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(516, 43);
            this.label1.TabIndex = 16;
            this.label1.Text = "Answers:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxRiddles
            // 
            this.textBoxRiddles.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxRiddles.Location = new System.Drawing.Point(138, 230);
            this.textBoxRiddles.Multiline = true;
            this.textBoxRiddles.Name = "textBoxRiddles";
            this.textBoxRiddles.Size = new System.Drawing.Size(516, 71);
            this.textBoxRiddles.TabIndex = 17;
            this.textBoxRiddles.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxRiddles_KeyPress);
            // 
            // textBoxAnswers
            // 
            this.textBoxAnswers.BackColor = System.Drawing.Color.White;
            this.textBoxAnswers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxAnswers.Location = new System.Drawing.Point(138, 380);
            this.textBoxAnswers.Name = "textBoxAnswers";
            this.textBoxAnswers.Size = new System.Drawing.Size(516, 23);
            this.textBoxAnswers.TabIndex = 18;
            this.textBoxAnswers.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxAnswers_KeyPress);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Cursor = System.Windows.Forms.Cursors.Help;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(124, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(547, 125);
            this.label3.TabIndex = 19;
            this.label3.Text = "You can write as many riddle as you want.\r\nYour riddles and answers must be separ" +
    "ated with \"|\". \r\nAlso riddles and answers must be the same number.\r\nClick \"ADD N" +
    "EW RIDDLE\" button when you are done.";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_add_new_riddles
            // 
            this.button_add_new_riddles.BackColor = System.Drawing.Color.White;
            this.button_add_new_riddles.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_add_new_riddles.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_add_new_riddles.FlatAppearance.BorderSize = 5;
            this.button_add_new_riddles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add_new_riddles.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_add_new_riddles.ForeColor = System.Drawing.Color.Black;
            this.button_add_new_riddles.Location = new System.Drawing.Point(668, 184);
            this.button_add_new_riddles.Name = "button_add_new_riddles";
            this.button_add_new_riddles.Size = new System.Drawing.Size(104, 219);
            this.button_add_new_riddles.TabIndex = 20;
            this.button_add_new_riddles.Text = "ADD\r\nNEW\r\nRIDDLES";
            this.button_add_new_riddles.UseVisualStyleBackColor = false;
            this.button_add_new_riddles.Click += new System.EventHandler(this.button_add_new_riddles_Click);
            // 
            // RiddleWriting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_add_new_riddles);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxAnswers);
            this.Controls.Add(this.textBoxRiddles);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RiddleWriting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RiddleWriting";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxRiddles;
        private System.Windows.Forms.TextBox textBoxAnswers;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_add_new_riddles;
    }
}