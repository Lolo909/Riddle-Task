﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace RiddleTask
{
    public partial class RiddleWriting : Form
    {
        static public List<string> newRiddlesList;
        static public List<string> newAnswersList;
        public RiddleWriting()
        {
            InitializeComponent();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            OptionalMenu optionalMenu = new OptionalMenu();
            optionalMenu.ShowDialog();
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        private void textBoxRiddles_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                e.Handled = true;
            }
        }

        private void textBoxAnswers_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                e.Handled = true;
            }
        }

        private void button_add_new_riddles_Click(object sender, EventArgs e)
        {
            int numberOfAnswersMarkers = 0;
            string checkTextBoxAnswers = textBoxAnswers.ToString();
            
            int numberOfRiddlesMarkers = 0;
            string checkTextBoxRiddles = textBoxRiddles.ToString();
            
            while (checkTextBoxAnswers.ToString().Contains("|"))
            {
                int indexOfTextBoxAnswersChar = checkTextBoxAnswers.IndexOf("|");
                checkTextBoxAnswers = checkTextBoxAnswers.Remove(indexOfTextBoxAnswersChar,1);
                numberOfAnswersMarkers++;
            }
            
            while (checkTextBoxRiddles.ToString().Contains("|"))
            {
                int indexOfTextBoxRiddlesChar = checkTextBoxRiddles.IndexOf("|");
                checkTextBoxRiddles = checkTextBoxRiddles.Remove(indexOfTextBoxRiddlesChar,1);
                numberOfRiddlesMarkers++;
            }


            if (numberOfAnswersMarkers==numberOfRiddlesMarkers && !String.IsNullOrEmpty(textBoxRiddles.Text) && !String.IsNullOrEmpty(textBoxAnswers.Text))
            {
                //TODO scheck if list work properly
                //newRiddlesList.AddRange(gettingRiddlesIntoList(textBoxRiddles.ToString()));
                //newAnswersList.AddRange(gettingAnswersIntoList(textBoxAnswers.ToString()));

                newRiddlesList = gettingRiddlesIntoList(textBoxRiddles.ToString());
                newAnswersList = gettingAnswersIntoList(textBoxAnswers.ToString());
                
                textBoxRiddles.Clear();
                textBoxAnswers.Clear();

                //?                
                //QuessRiddle.allRiddles.AddRange(newRiddlesList);
                //QuessRiddle.allAnswers.AddRange(newAnswersList);

                foreach (string riddle in newRiddlesList)
                {
                    QuessRiddle.allRiddles.Add(riddle);
                }

                foreach (string answer in newAnswersList)
                {
                    QuessRiddle.allAnswers.Add(answer);
                }

                newAnswersList.Clear();
                newRiddlesList.Clear();

            }
            else
            {
                if (String.IsNullOrEmpty(textBoxAnswers.Text) || String.IsNullOrEmpty(textBoxRiddles.Text))
                {
                  MessageBox.Show("Write riddles AND Answers!");
                }
                else {
                    MessageBox.Show("Riddles and answers must be the same number!");
                }
               
               
                //dont put enything and pop messages
            }
            
        }

        static public List<string> gettingRiddlesIntoList(string newRiddles)
        {
            string reworkedText = "";
            try
            {
                int length = newRiddles.Length;
                reworkedText = newRiddles.Substring(35, newRiddles.Length-35); // This throws ArgumentOutOfRangeException.
                
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
            }

           
            List<string> riddles = new List<string>();
            riddles = reworkedText.Split("|").ToList();
            
                       
            return riddles;
        }

        static public List<string> gettingAnswersIntoList(string newAnswers)
        {
            string reworkedText = "";
            try
            {
                int length = newAnswers.Length;
                reworkedText = newAnswers.Substring(35, newAnswers.Length - 35); // This throws ArgumentOutOfRangeException.

            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
            }


            List<string> answers = new List<string>();
            answers = reworkedText.Split("|").ToList();


            return answers;
        }
    }
}
