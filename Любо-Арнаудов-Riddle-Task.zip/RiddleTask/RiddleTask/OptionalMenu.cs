﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace RiddleTask
{
    public partial class OptionalMenu : Form
    {
        public OptionalMenu()
        {
            InitializeComponent();
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button_write_a_riddle_Click(object sender, EventArgs e)
        {
            this.Hide();
            RiddleWriting riddleWriting = new RiddleWriting();
            riddleWriting.ShowDialog();
        }

        private void button_to_guess_riddle_Click(object sender, EventArgs e)
        {
            this.Hide();
            QuessRiddle quessRiddle = new QuessRiddle();
            quessRiddle.ShowDialog();
        }

        private void save_all_riddles_Click(object sender, EventArgs e)
        {
            string folder = Application.StartupPath;
            string fileName = "Riddles.txt";
            string fullPath = folder + fileName;

            List<string> allRiddlesAndAnswers = new List<string>();

            for (int i = 0; i < QuessRiddle.allRiddles.Count; i++)
            {
                allRiddlesAndAnswers.Add("Riddle: " + QuessRiddle.allRiddles[i] + " Answer: " + QuessRiddle.allAnswers[i]);
            }

            File.WriteAllLines(fullPath, allRiddlesAndAnswers);
        }

        
    }
}
