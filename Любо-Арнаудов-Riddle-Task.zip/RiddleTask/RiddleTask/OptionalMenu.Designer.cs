﻿
namespace RiddleTask
{
    partial class OptionalMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionalMenu));
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.exit_button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button_write_a_riddle = new System.Windows.Forms.Button();
            this.button_to_guess_riddle = new System.Windows.Forms.Button();
            this.save_all_riddles = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Black;
            this.pictureBox4.Location = new System.Drawing.Point(-3, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(806, 21);
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 431);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(806, 21);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.Location = new System.Drawing.Point(780, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 451);
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Black;
            this.pictureBox3.Location = new System.Drawing.Point(-3, 1);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(20, 451);
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // exit_button
            // 
            this.exit_button.BackColor = System.Drawing.Color.White;
            this.exit_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("exit_button.BackgroundImage")));
            this.exit_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.exit_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exit_button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.exit_button.FlatAppearance.BorderSize = 5;
            this.exit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_button.Location = new System.Drawing.Point(727, 27);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(47, 44);
            this.exit_button.TabIndex = 10;
            this.exit_button.UseVisualStyleBackColor = false;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Cursor = System.Windows.Forms.Cursors.Help;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(90, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(607, 139);
            this.label2.TabIndex = 12;
            this.label2.Text = " What do you want?";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_write_a_riddle
            // 
            this.button_write_a_riddle.BackColor = System.Drawing.Color.White;
            this.button_write_a_riddle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_write_a_riddle.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_write_a_riddle.FlatAppearance.BorderSize = 5;
            this.button_write_a_riddle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_write_a_riddle.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_write_a_riddle.ForeColor = System.Drawing.Color.Black;
            this.button_write_a_riddle.Location = new System.Drawing.Point(90, 230);
            this.button_write_a_riddle.Name = "button_write_a_riddle";
            this.button_write_a_riddle.Size = new System.Drawing.Size(445, 73);
            this.button_write_a_riddle.TabIndex = 13;
            this.button_write_a_riddle.Text = "Write a riddle?";
            this.button_write_a_riddle.UseVisualStyleBackColor = false;
            this.button_write_a_riddle.Click += new System.EventHandler(this.button_write_a_riddle_Click);
            // 
            // button_to_guess_riddle
            // 
            this.button_to_guess_riddle.BackColor = System.Drawing.Color.White;
            this.button_to_guess_riddle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_to_guess_riddle.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_to_guess_riddle.FlatAppearance.BorderSize = 5;
            this.button_to_guess_riddle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_to_guess_riddle.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_to_guess_riddle.ForeColor = System.Drawing.Color.Black;
            this.button_to_guess_riddle.Location = new System.Drawing.Point(90, 326);
            this.button_to_guess_riddle.Name = "button_to_guess_riddle";
            this.button_to_guess_riddle.Size = new System.Drawing.Size(445, 73);
            this.button_to_guess_riddle.TabIndex = 14;
            this.button_to_guess_riddle.Text = "To guess riddles?";
            this.button_to_guess_riddle.UseVisualStyleBackColor = false;
            this.button_to_guess_riddle.Click += new System.EventHandler(this.button_to_guess_riddle_Click);
            // 
            // save_all_riddles
            // 
            this.save_all_riddles.BackColor = System.Drawing.Color.White;
            this.save_all_riddles.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_all_riddles.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.save_all_riddles.FlatAppearance.BorderSize = 5;
            this.save_all_riddles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.save_all_riddles.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.save_all_riddles.ForeColor = System.Drawing.Color.Black;
            this.save_all_riddles.Location = new System.Drawing.Point(541, 230);
            this.save_all_riddles.Name = "save_all_riddles";
            this.save_all_riddles.Size = new System.Drawing.Size(156, 169);
            this.save_all_riddles.TabIndex = 15;
            this.save_all_riddles.Text = "Save all ridddles";
            this.save_all_riddles.UseVisualStyleBackColor = false;
            this.save_all_riddles.Click += new System.EventHandler(this.save_all_riddles_Click);
            // 
            // OptionalMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.save_all_riddles);
            this.Controls.Add(this.button_to_guess_riddle);
            this.Controls.Add(this.button_write_a_riddle);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox4);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OptionalMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OptionalMenu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_write_a_riddle;
        private System.Windows.Forms.Button button_to_guess_riddle;
        private System.Windows.Forms.Button save_all_riddles;
    }
}