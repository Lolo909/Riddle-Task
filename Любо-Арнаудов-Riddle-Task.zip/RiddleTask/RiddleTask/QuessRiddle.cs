﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RiddleTask
{
    public partial class QuessRiddle : Form
    {
        static public List<string> allRiddles = new List<string> { 
            "What has to be broken before you can use it?", 
            "I'm tall when I'm young, and I'm short when I'm old. What am I?",
        "What is full of holes but still holds water?",
        "What is always in front of you but can't be seen?",
        "What gets wet while drying?",
        "I shave every day, but my beard stays the same. What am I?",
        "What can’t talk but will reply when spoken to?",
        "David's parents have three sons: Snap, Crackle, and what's the name of the third son?",
        "I follow you all the time and copy your every move, but you can't touch me or catch me. What am I?",
        "What has many keys but can't open a single lock?"};
        static public List<string> allAnswers = new List<string> { 
            "egg", "candle", "sponge", "future", "towel", 
            "barber", "echo", "David", "shadow","piano" };
        Boolean isItQuessed = false;
        Boolean isEnterPressed = false;
        int lastRememberedRandom = 0;

        int randomIndex = 0;
        public QuessRiddle()
        {
            InitializeComponent();
            
            label1.Hide();
            textBoxAnswers.Hide();
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            OptionalMenu optionalMenu = new OptionalMenu();
            optionalMenu.ShowDialog();
        }

        private void button_give_me_riddle_Click(object sender, EventArgs e)
        {
            label1.Show();
            textBoxAnswers.Show();

            textBoxAnswers.Clear();

            
            isItQuessed = false;
            isEnterPressed = false;
            
            button_show_me_answer.Text = "Show me the answer?";
            Random rand = new Random();            
            randomIndex = rand.Next(0, allRiddles.Count);
            
            while (lastRememberedRandom == randomIndex)
            {
                randomIndex = rand.Next(0, allRiddles.Count);
            }
            lastRememberedRandom = randomIndex;

            string riddleForQuess = allRiddles[randomIndex];
            Riddle_display.Text = riddleForQuess;
        }

        private void button_show_me_answer_Click(object sender, EventArgs e)
        {
            if (isItQuessed && isEnterPressed && textBoxAnswers.Text.Length != 0)
            {
                button_show_me_answer.Text = allAnswers[randomIndex];
            }
            else
            {
                MessageBox.Show("You must first try to answer the riddle!");
            }
        }

        private void textBoxAnswers_KeyPress(object sender, KeyPressEventArgs e)
        {
            

                if (e.KeyChar == Convert.ToChar(Keys.Enter))
                {
                isEnterPressed = true;
                isItQuessed = true;

                    if (textBoxAnswers.Text.ToUpper().Equals((allAnswers[randomIndex]).ToUpper()) 
                    && isItQuessed && isEnterPressed && !textBoxAnswers.Text.Length.Equals(""))
                    {
                        Riddle_display.Text = "CORRECT";
                    }else if(isItQuessed && isEnterPressed && textBoxAnswers.Text.Equals(""))
                    {
                    MessageBox.Show("You must first try to answer the riddle!");
                    }
                    else
                    {
                        Riddle_display.Text = "INCORRECT";
                    }
                }


        }
    }
}
